package com.mydetailing.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.drawable.GradientDrawable

class MainActivity : Activity() {
    private val bg = Color.rgb(9,10,13)
    private val card = Color.rgb(20,22,27)
    private val white = Color.WHITE
    private val gray = Color.rgb(170,174,183)
    private val red = Color.rgb(220,38,38)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun tv(text: String, size: Float, bold: Boolean=false): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(white)
            if (bold) typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 8, 0, 8)
        }

    private fun button(text: String, action: () -> Unit): Button =
        Button(this).apply {
            this.text = text
            textSize = 15f
            setTextColor(white)
            background = GradientDrawable().apply {
                setColor(red); cornerRadius = 22f
            }
            setOnClickListener { action() }
            isAllCaps = false
        }

    private fun base(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(24, 28, 24, 24)
        setBackgroundColor(bg)
    }

    private fun showHome() {
        val root = base()
        root.addView(tv("МОЙ ДЕТЕЙЛИНГ", 27f, true))
        root.addView(tv("Профессиональный уход за автомобилем", 15f).apply { setTextColor(gray) })

        val space = Space(this)
        root.addView(space, LinearLayout.LayoutParams(1, 24))

        val cardBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 18, 20, 18)
            background = GradientDrawable().apply { setColor(card); cornerRadius = 28f }
        }
        cardBox.addView(tv("Добро пожаловать 👋", 21f, true))
        cardBox.addView(tv("Здесь можно быстро оформить заказ и рассчитать стоимость.", 15f).apply { setTextColor(gray) })
        root.addView(cardBox, LinearLayout.LayoutParams(-1, -2))

        root.addView(Space(this), LinearLayout.LayoutParams(1, 18))
        root.addView(button("🚗  Записать автомобиль") { showBooking() },
            LinearLayout.LayoutParams(-1, 54).apply { bottomMargin = 12 })
        root.addView(button("🧽  Услуги и цены") { showServices() },
            LinearLayout.LayoutParams(-1, 54).apply { bottomMargin = 12 })
        root.addView(button("📋  Мои заказы") { showOrders() },
            LinearLayout.LayoutParams(-1, 54))

        setContentView(root)
    }

    private fun showServices() {
        val root = base()
        root.addView(tv("Услуги и цены", 26f, true))
        val services = listOf(
            "Комплексная мойка — от 700 грн",
            "Химчистка салона — от 1800 грн",
            "Полировка кузова — от 2500 грн",
            "Керамическое покрытие — от 3500 грн",
            "Детейлинг мойка — от 1200 грн"
        )
        services.forEach {
            val row = tv("• $it", 16f).apply {
                setTextColor(white)
                setPadding(0, 18, 0, 18)
            }
            root.addView(row)
        }
        root.addView(Space(this), LinearLayout.LayoutParams(1, 10))
        root.addView(button("← На главную") { showHome() }, LinearLayout.LayoutParams(-1, 54))
        setContentView(root)
    }

    private fun showBooking() {
        val root = base()
        root.addView(tv("Запись автомобиля", 26f, true))
        val name = EditText(this).apply { hint="Имя клиента"; setTextColor(white); setHintTextColor(gray) }
        val car = EditText(this).apply { hint="Автомобиль"; setTextColor(white); setHintTextColor(gray) }
        val phone = EditText(this).apply { hint="Телефон"; setTextColor(white); setHintTextColor(gray); inputType=3 }
        val service = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("Комплексная мойка", "Химчистка салона", "Полировка кузова", "Керамика", "Детейлинг мойка"))
        }
        listOf(name, car, phone).forEach { root.addView(it, LinearLayout.LayoutParams(-1, 58).apply { bottomMargin=8 }) }
        root.addView(service, LinearLayout.LayoutParams(-1, 58))
        root.addView(Space(this), LinearLayout.LayoutParams(1, 14))
        root.addView(button("Сохранить заказ") {
            Toast.makeText(this, "Заказ сохранён", Toast.LENGTH_SHORT).show()
        }, LinearLayout.LayoutParams(-1, 54).apply { bottomMargin=10 })
        root.addView(button("← На главную") { showHome() }, LinearLayout.LayoutParams(-1, 54))
        setContentView(root)
    }

    private fun showOrders() {
        val root = base()
        root.addView(tv("Мои заказы", 26f, true))
        root.addView(tv("Пока заказов нет.", 17f).apply { setTextColor(gray) })
        root.addView(Space(this), LinearLayout.LayoutParams(1, 18))
        root.addView(button("＋ Добавить заказ") { showBooking() }, LinearLayout.LayoutParams(-1, 54).apply { bottomMargin=10 })
        root.addView(button("← На главную") { showHome() }, LinearLayout.LayoutParams(-1, 54))
        setContentView(root)
    }
}
